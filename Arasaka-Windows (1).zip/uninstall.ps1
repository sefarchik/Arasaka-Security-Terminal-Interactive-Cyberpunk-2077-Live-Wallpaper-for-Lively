﻿$ErrorActionPreference = "SilentlyContinue"
$ru = (Get-Culture).TwoLetterISOLanguageName -eq "ru"
function T($r, $e) { if ($ru) { $r } else { $e } }
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like "*media-helper.ps1*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Remove-Item (Join-Path ([Environment]::GetFolderPath("Startup")) "ArasakaMediaHelper.vbs") -Force
Remove-Item (Join-Path $env:LOCALAPPDATA "ArasakaTerminal") -Recurse -Force
foreach ($l in @((Join-Path $env:LOCALAPPDATA "Packages\12030rocksdanister.LivelyWallpaper_97hta09mmv6hy\LocalCache\Local\Lively Wallpaper\Library\wallpapers\ArasakaTerminal"), (Join-Path $env:LOCALAPPDATA "Lively Wallpaper\Library\wallpapers\ArasakaTerminal"))) { Remove-Item $l -Recurse -Force }
Write-Host (T "Удалено: автозапуск помощника и файлы. Если обои были выбраны в Lively, закройте их в самом Lively." "Removed: helper autostart and files. If the wallpaper is selected in Lively, close it in Lively itself.")
