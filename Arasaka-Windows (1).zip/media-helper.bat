@echo off
title Arasaka media helper
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0media-helper.ps1"
pause
