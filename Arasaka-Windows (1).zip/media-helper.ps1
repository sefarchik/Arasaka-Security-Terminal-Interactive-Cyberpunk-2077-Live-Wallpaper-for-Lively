# Arasaka media helper. Windows PowerShell 5.1 (built into Windows).
# Serves player state (title, position, duration) and accepts commands on 127.0.0.1:5511 only.
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) {
  $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
  $t.Wait(-1) | Out-Null
  $t.Result
}
[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime] | Out-Null
$mgrType  = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]
$propType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]
$mgr = Await ($mgrType::RequestAsync()) $mgrType

$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://127.0.0.1:5511/")
$l.Start()
Write-Host "Arasaka media helper: http://127.0.0.1:5511  (close this window to stop)"

while ($l.IsListening) {
  $c = $l.GetContext()
  $body = "{}"
  try {
    $s = $mgr.GetCurrentSession()
    if ($s) {
      switch ($c.Request.Url.AbsolutePath) {
        "/playpause" { [void](Await ($s.TryTogglePlayPauseAsync()) ([bool])) }
        "/next"      { [void](Await ($s.TrySkipNextAsync()) ([bool])) }
        "/prev"      { [void](Await ($s.TrySkipPreviousAsync()) ([bool])) }
        "/seek"      { $ms = [double]$c.Request.QueryString["ms"]; [void](Await ($s.TryChangePlaybackPositionAsync([long]($ms * 10000))) ([bool])) }
      }
      $p  = Await ($s.TryGetMediaPropertiesAsync()) $propType
      $tl = $s.GetTimelineProperties()
      $pb = $s.GetPlaybackInfo()
      $status = [string]$pb.PlaybackStatus
      $pos = $tl.Position.TotalMilliseconds
      if ($status -eq "Playing") { $pos += ([DateTimeOffset]::UtcNow - $tl.LastUpdatedTime).TotalMilliseconds }
      $dur = ($tl.EndTime - $tl.StartTime).TotalMilliseconds
      if ($dur -gt 0 -and $pos -gt $dur) { $pos = $dur }
      $body = @{ title = $p.Title; artist = $p.Artist; album = $p.AlbumTitle; status = $status
                 pos = [math]::Round($pos); dur = [math]::Round($dur)
                 canSeek = [bool]$pb.Controls.IsPlaybackPositionEnabled; canNext = [bool]$pb.Controls.IsNextEnabled; canPrev = [bool]$pb.Controls.IsPreviousEnabled } | ConvertTo-Json -Compress
    }
  } catch { $body = "{}" }
  $c.Response.Headers.Add("Access-Control-Allow-Origin", "*")
  $c.Response.ContentType = "application/json; charset=utf-8"
  $bytes = [Text.Encoding]::UTF8.GetBytes($body)
  $c.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $c.Response.Close()
}
