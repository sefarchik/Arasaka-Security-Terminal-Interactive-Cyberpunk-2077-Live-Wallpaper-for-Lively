# Arasaka Terminal: Windows build (live wallpaper)

A flat red-and-black corporate HUD inspired by sci-fi megacorp terminals, with real, useful data. Fan project, not affiliated with any rights holder.

## Install
1. Unzip anywhere.
2. Double-click `install.bat`. It copies the files, sets the player helper to start with Windows (no window) and installs the wallpaper into [Lively Wallpaper](https://github.com/rocksdanister/lively) (free).
3. If Lively is not found, drag `ArasakaTerminal.zip` into the Lively window.
4. In Lively settings, enable mouse input for wallpapers (needed to click the panels).

Uninstall: `uninstall.bat`. Preview without Lively: `start.bat` (Edge kiosk mode, Alt+F4 to exit).

## What it shows
Weather (Open-Meteo, no key), CPU/GPU/RAM load with a graph, media player (cover, seek bar, prev/pause/next, equalizer: bass bars, mids line, highs ticks), calendar with day countdown, internet status/ping/speed test, world clocks, event log.
Panels collapse (click header) and can be dragged. Click the central logo to replay the login animation. F = fullscreen.

## Language
English or Russian, chosen automatically from your system language. The `EN/RU` button in the footer switches it, or set `lang: "en"` in the `CFG` block at the top of `script.js`.

## Notes
- CPU/GPU/RAM, cover art and the equalizer come from Lively. The seek bar and buttons need the helper (`media-helper.ps1`, installed automatically; Windows PowerShell 5.1).
- If a player has no next/previous (for example a single YouTube video), the buttons seek 10 s instead.
- Set your city and time zones in `CFG` (top of `script.js`). Taskbar offset: `--taskbar` in `styles.css`. Your own logo: put `logo.png` next to `index.html`.
