﻿$ErrorActionPreference = "Stop"
$ru = (Get-Culture).TwoLetterISOLanguageName -eq "ru"
function T($r, $e) { if ($ru) { $r } else { $e } }
$src = $PSScriptRoot
$coreSrc = $src
$app = Join-Path $env:LOCALAPPDATA "ArasakaTerminal"
$files = "index.html", "script.js", "styles.css", "LivelyInfo.json", "logo.svg"

Write-Host ""
Write-Host (T "=== ARASAKA TERMINAL: УСТАНОВКА ===" "=== ARASAKA TERMINAL: INSTALL ===") -ForegroundColor Red

# 0. Если основных файлов рядом нет, берём их из ArasakaTerminal.zip
if (-not (Test-Path (Join-Path $src "index.html"))) {
  $zip = Join-Path $src "ArasakaTerminal.zip"
  if (-not (Test-Path $zip)) {
    Write-Host (T "Рядом с install.ps1 нет ни index.html, ни ArasakaTerminal.zip. Положите все файлы в одну папку." "Neither index.html nor ArasakaTerminal.zip found next to install.ps1. Put all files in one folder.") -ForegroundColor Red
    exit 1
  }
  $coreSrc = Join-Path $env:TEMP "ArasakaTerminal_src"
  Remove-Item $coreSrc -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -Path $zip -DestinationPath $coreSrc -Force
}
if (-not (Test-Path (Join-Path $src "media-helper.ps1"))) {
  Write-Host (T "Не найден media-helper.ps1 рядом с install.ps1." "media-helper.ps1 not found next to install.ps1.") -ForegroundColor Red
  exit 1
}

# 1. Файлы
Write-Host (T "[1/3] Копирование файлов..." "[1/3] Copying files...")
New-Item -ItemType Directory -Force $app | Out-Null
foreach ($f in $files) { Copy-Item (Join-Path $coreSrc $f) $app -Force }
if (Test-Path (Join-Path $coreSrc "logo.png")) { Copy-Item (Join-Path $coreSrc "logo.png") $app -Force }
Copy-Item (Join-Path $src "media-helper.ps1") $app -Force

# 2. Помощник плеера: автозапуск без окна + запуск прямо сейчас
Write-Host (T "[2/3] Помощник плеера (автозапуск)..." "[2/3] Player helper (autostart)...")
$vbs = Join-Path $app "media-helper-hidden.vbs"
$line = 'CreateObject("Wscript.Shell").Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + (Join-Path $app "media-helper.ps1") + '""", 0, False'
Set-Content -Path $vbs -Value $line -Encoding Unicode
Copy-Item $vbs (Join-Path ([Environment]::GetFolderPath("Startup")) "ArasakaMediaHelper.vbs") -Force
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like "*media-helper.ps1*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Process wscript.exe -ArgumentList ('"' + $vbs + '"')

# 3. Lively
Write-Host (T "[3/3] Установка обоев в Lively..." "[3/3] Installing wallpaper into Lively...")
$done = $false
try {
  $lib = @(
    (Join-Path $env:LOCALAPPDATA "Packages\12030rocksdanister.LivelyWallpaper_97hta09mmv6hy\LocalCache\Local\Lively Wallpaper\Library\wallpapers"),
    (Join-Path $env:LOCALAPPDATA "Lively Wallpaper\Library\wallpapers")
  ) | Where-Object { Test-Path $_ } | Select-Object -First 1

  $cands = @(
    (Join-Path $env:LOCALAPPDATA "Programs\Lively Wallpaper\Lively.exe"),
    (Join-Path $env:ProgramFiles "Lively Wallpaper\Lively.exe"),
    (Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\Lively.exe")
  )
  $pkg = Get-AppxPackage -Name "*LivelyWallpaper*" -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($pkg) { $cands += (Join-Path $pkg.InstallLocation "Lively.exe") }
  $exe = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $exe) { $c = Get-Command Lively.exe, livelycu.exe -ErrorAction SilentlyContinue | Select-Object -First 1; if ($c) { $exe = $c.Source } }

  if ($lib -and $exe) {
    $dest = Join-Path $lib "ArasakaTerminal"
    New-Item -ItemType Directory -Force $dest | Out-Null
    foreach ($f in $files) { Copy-Item (Join-Path $coreSrc $f) $dest -Force }
    if (Test-Path (Join-Path $coreSrc "logo.png")) { Copy-Item (Join-Path $coreSrc "logo.png") $dest -Force }
    # В версии из Microsoft Store команде нужен «обычный» путь LocalAppData
    $cmdPath = if ($lib -like "*Packages*") { Join-Path $env:LOCALAPPDATA "Lively Wallpaper\Library\wallpapers\ArasakaTerminal" } else { $dest }
    Start-Process $exe -ArgumentList @("setwp", "--file", ('"' + $cmdPath + '"'))
    Start-Sleep -Seconds 3
    $done = $true
  }
} catch { }

Write-Host ""
if ($done) {
  Write-Host (T "Готово. Обои применены, помощник плеера запускается вместе с Windows." "Done. Wallpaper applied; the player helper starts with Windows.") -ForegroundColor Green
  Write-Host (T "Если в Lively их нет в списке, перезапустите Lively (обои уже должны быть на рабочем столе)." "If it is not in Lively's list, restart Lively (the wallpaper should already be on your desktop).")
} else {
  Write-Host (T "Помощник плеера установлен и запущен." "Player helper installed and running.") -ForegroundColor Green
  Write-Host (T "Lively найти не удалось. Перетащите файл ArasakaTerminal.zip в окно Lively, и всё." "Lively not found. Drag ArasakaTerminal.zip into the Lively window and you are done.") -ForegroundColor Yellow
}
Write-Host (T "Не забудьте включить ввод мыши для обоев в настройках Lively (для кликов по панелям)." "Remember to enable mouse input for wallpapers in Lively settings (needed to click panels).")
