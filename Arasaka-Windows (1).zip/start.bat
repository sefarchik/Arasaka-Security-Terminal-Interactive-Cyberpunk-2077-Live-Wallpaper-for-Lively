@echo off
rem Открывает терминал на весь экран (выход: Alt+F4). Нужен только браузер, ничего устанавливать не надо.
where msedge >nul 2>nul
if %errorlevel%==0 (
  start "" msedge --kiosk "%~dp0index.html" --edge-kiosk-type=fullscreen
) else (
  start "" "%~dp0index.html"
)
