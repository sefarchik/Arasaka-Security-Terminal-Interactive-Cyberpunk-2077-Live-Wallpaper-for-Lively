\*\*As a wallpaper (recommended): Lively Wallpaper\*\* — drag and drop the folder or `.zip` archive into the Lively window (requires `LivelyInfo.json`). This enables CPU/GPU/RAM/network monitoring and the "Now Playing" media widget.

\*\*Preview only:\*\* run `start.bat` (opens `index.html` in fullscreen, press `Alt+F4` to exit). Hardware load stats are unavailable in a regular browser, while all other features work.



City and time zones can be changed at the top of `script.js` (inside the `CFG` block). Weather data: Open-Meteo (internet connection required).

